/* 
 * File:   main.cpp
 * Author: Christopher Vasquez
 * Created on March 4, 2015, 9:29 AM
 * Purpose: Chp 2 Homework
 */
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    cout<<"   *  "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" *****  "<<endl;
    cout<<"*******  "<<endl;
    cout<<" *****  "<<endl;
    cout<<"  ***  "<<endl;
    cout<<"   *  "<<endl;
    
    return 0;
}

