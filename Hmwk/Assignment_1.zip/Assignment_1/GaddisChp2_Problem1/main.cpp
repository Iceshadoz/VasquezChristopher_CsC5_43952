/* 
 * File:   main.cpp
 * Author: Christopher Vasquez
 * Created on March 4, 2015, 9:29 AM
 * Purpose: Chp 2 Homework
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    int num1 = 62;
    int num2 = 99;
    cout << "The first number is " << num1 << ", and the second number is "
         << num2 << ". Their sum is " << num1+num2 << endl;
    
    return 0;
}

