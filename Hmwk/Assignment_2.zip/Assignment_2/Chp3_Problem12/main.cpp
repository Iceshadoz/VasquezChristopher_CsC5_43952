/* 
 * File:   main.cpp
 * Author: c_vas_000
 *
 * Created on March 16, 2015, 10:47 AM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

