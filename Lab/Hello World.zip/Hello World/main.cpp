/* 
 * File:   main.cpp
 * Author: Christopher Vasquez
 * Created on May 13, 2015, 8:55 AM
 */

#include <cstdlib>
#include <iostream>
using namespace std;
//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    cout<<"Hello World"<<endl;
    return 0;
}

